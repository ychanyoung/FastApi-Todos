import requests
import pdfplumber
import io
import json
 
URL = (
    "https://scc.sogang.ac.kr/Download3"
    "?pathStr=MTAxIyMxMDgjIzEwNSMjMTAyIyMxMTUjIzEwOSMjOTkjIzQ3IyM5NyMjMTE2IyM5NyMjMTAwIyM0NyMjMTI0IyMxMDQjIzExNiMjOTcjIzgwIyMxMDEjIzEwOCMjMTA1IyMxMDIjIzM1IyMzMyMjMzUjIzQ5IyMxMjQjIzEyMCMjMTAxIyMxMDAjIzExMCMjMTA1IyMzNSMjMzMjIzM1IyM1MCMjNDkjIzU3IyM1MyMjNDkjIzEyNCMjMTAwIyMxMDUjIzEwNyMjMTEy"
    "&fileName=2026%C3%AD%C2%95%C2%99%C3%AB%C2%85%C2%84%C3%AB%C2%8F%C2%84+1%C3%AD%C2%95%C2%99%C3%AA%C2%B8%C2%B0+%C3%AA%C2%B5%C2%B0%C3%AC%C2%9D%C2%B4%C3%AB%C2%9F%C2%AC%C3%AB%C2%8B%C2%9D+%C3%AD%C2%95%C2%99%C3%AC%C2%A0%C2%90%C3%AC%C2%9D%C2%B8%C3%AC%C2%A0%C2%95+%C3%AC%C2%8B%C2%A0%C3%AC%C2%B2%C2%AD%C3%AC%C2%A0%C2%88%C3%AC%C2%B0%C2%A8+%C3%AC%C2%95%C2%88%C3%AB%C2%82%C2%B4_20260226.pdf"
    "&gubun=cmsfile"
)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://scc.sogang.ac.kr/",
}
 
def download_pdf(url: str) -> bytes:
    """URL에서 PDF를 다운로드해 바이트로 반환"""
    resp = requests.get(url, headers=HEADERS, timeout=30)
    resp.raise_for_status()
 
    content_type = resp.headers.get("Content-Type", "")
    if "pdf" not in content_type and len(resp.content) < 100:
        raise ValueError(f"PDF가 아닐 수 있습니다. Content-Type: {content_type}")
 
    print(f"✅ 다운로드 완료: {len(resp.content):,} bytes")
    return resp.content
 
 
def extract_text(pdf_bytes: bytes) -> dict:
    """PDF 바이트에서 텍스트와 테이블을 추출"""
    result = {"pages": [], "tables": []}
 
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        print(f"📄 총 페이지: {len(pdf.pages)}")
 
        for i, page in enumerate(pdf.pages, 1):
            # 텍스트 추출
            text = page.extract_text() or ""
            result["pages"].append({"page": i, "text": text})
 
            # 테이블 추출
            tables = page.extract_tables()
            for j, table in enumerate(tables):
                result["tables"].append({"page": i, "table_index": j, "data": table})
 
    return result
 
 
def save_results(result: dict, output_prefix: str = "output"):
    """추출 결과를 텍스트 파일과 JSON으로 저장"""
 
    # 전체 텍스트 저장
    txt_path = f"{output_prefix}.txt"
    with open(txt_path, "w", encoding="utf-8") as f:
        for page_info in result["pages"]:
            f.write(f"\n{'='*50}\n")
            f.write(f"[Page {page_info['page']}]\n")
            f.write(f"{'='*50}\n")
            f.write(page_info["text"])
            f.write("\n")
    print(f"💾 텍스트 저장: {txt_path}")
 
    # 테이블이 있으면 JSON으로도 저장
    if result["tables"]:
        json_path = f"{output_prefix}_tables.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result["tables"], f, ensure_ascii=False, indent=2)
        print(f"💾 테이블 저장: {json_path}")
 
    return txt_path
 
 
if __name__ == "__main__":
    print("🔽 PDF 다운로드 중...")
    pdf_bytes = download_pdf(URL)
 
    print("📝 텍스트 추출 중...")
    result = extract_text(pdf_bytes)
 
    # 첫 페이지 미리보기
    first_text = result["pages"][0]["text"] if result["pages"] else ""
    print("\n--- 첫 페이지 미리보기 ---")
    print(first_text[:500])
    print("...\n")
 
    save_results(result, output_prefix="sogang_pdf")
    print("✅ 완료!")
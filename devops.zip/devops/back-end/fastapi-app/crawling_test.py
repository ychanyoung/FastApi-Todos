import requests
import os
from bs4 import BeautifulSoup
import pdfplumber



HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://www.sogang.ac.kr/",
}

BASE_URL = "https://www.sogang.ac.kr"
DOWNLOAD_BASE = "https://scc.sogang.ac.kr/Download3"


# ── Viewer URL → Download URL 변환 ───────────────────────────────

def to_download_url(url: str) -> str:
    """
    scc.sogang.ac.kr viewer URL에서 pathStr·fileName을 추출해
    Download3 직접 다운로드 URL로 변환.
    pathStr이 없으면 원본 URL을 그대로 반환.
    """
    PATH_STR_KEY = "pathStr%3D"
    FILENAME_KEY = "%26fileName%3D"
    GUBUN_KEY    = "%26gubun"

    pathStr_index  = url.find(PATH_STR_KEY)
    if pathStr_index == -1:
        return url  # pathStr 없으면 변환 불가

    filename_index = url.find(FILENAME_KEY)
    gubun_index    = url.find(GUBUN_KEY)

    # pathStr 값: PATH_STR_KEY 이후 ~ FILENAME_KEY 이전
    path_str_value = url[pathStr_index + len(PATH_STR_KEY) : filename_index]

    # fileName 값: FILENAME_KEY 이후 ~ GUBUN_KEY 이전 (없으면 끝까지)
    if filename_index != -1:
        filename_start = filename_index + len(FILENAME_KEY)
        filename_end   = gubun_index if gubun_index != -1 else len(url)
        file_name_value = url[filename_start : filename_end]
        return f"{DOWNLOAD_BASE}?pathStr={path_str_value}&fileName={file_name_value}&gubun=cmsfile"

    return f"{DOWNLOAD_BASE}?pathStr={path_str_value}&gubun=cmsfile"


# ── PDF 다운로드 및 텍스트 추출 ───────────────────────────────────

def download_pdf(url: str, save_path: str) -> None:
    """URL에서 PDF를 다운로드해 파일로 저장"""
    resp = requests.get(url, headers=HEADERS, timeout=30)
    resp.raise_for_status()

    content_type = resp.headers.get("Content-Type", "")
    if "pdf" not in content_type and len(resp.content) < 100:
        raise ValueError(f"PDF가 아닐 수 있습니다. Content-Type: {content_type}")

    with open(save_path, "wb") as f:
        f.write(resp.content)
    print(f"    다운로드 완료: {len(resp.content):,} bytes → {save_path}")


def extract_pdf_text(pdf_path: str) -> dict:
    """PDF 파일에서 텍스트와 테이블을 추출"""
    result = {"pages": [], "tables": []}

    with pdfplumber.open(pdf_path) as pdf:
        print(f"    총 페이지: {len(pdf.pages)}")

        for i, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            result["pages"].append({"page": i, "text": text})

            tables = page.extract_tables()
            for j, table in enumerate(tables):
                result["tables"].append({"page": i, "table_index": j, "data": table})

    return result


# ── PDF URL 탐지 ──────────────────────────────────────────────────

def find_pdf_urls(html: str, api_data: dict) -> list:
    """
    HTML 콘텐츠와 API 응답에서 PDF URL을 수집.
    1) HTML 내 <a>, <iframe>, <embed> 태그의 href/src 검사
    2) API 응답의 첨부파일 필드(fileList, attachFiles 등) 검사
    """
    soup = BeautifulSoup(html, "html.parser")
    pdf_urls = []

    # HTML 내 링크 탐색
    for tag, attr in [("a", "href"), ("iframe", "src"), ("embed", "src")]:
        for el in soup.find_all(tag, **{attr: True}):
            val = el[attr]
            if ".pdf" in val.lower() or "Download" in val or "pathStr=" in val or "pathStr%3D" in val:
                pdf_urls.append(val)

    # API 응답의 첨부파일 필드 탐색
    for field in ("fileList", "attachFiles", "files", "attachList"):
        items = api_data.get(field) or []
        for item in items:
            for key in ("url", "fileUrl", "filePath", "downloadUrl"):
                val = item.get(key, "")
                if val and (".pdf" in val.lower() or "Download" in val or "pathStr=" in val):
                    if val not in pdf_urls:
                        pdf_urls.append(val)
                    break

    # 상대 경로 → 절대 경로 변환
    absolute = []
    for url in pdf_urls:
        if url.startswith("http"):
            absolute.append(url)
        elif url.startswith("/"):
            absolute.append(BASE_URL + url)
        else:
            absolute.append(BASE_URL + "/" + url)

    # Viewer URL → Download3 URL 변환
    converted = [to_download_url(u) for u in absolute]

    # 중복 제거
    return list(dict.fromkeys(converted))


# ── 메인 크롤링 ──────────────────────────────────────────────────

def crawl_notices(page_count: int = 1, output_file: str = "crawl_test.txt"):
    with open(output_file, "w", encoding="utf-8") as f:

        for page in range(1, page_count + 1):
            list_url = (
                f"{BASE_URL}/api/api/v1/mainKo/BbsData/boardList"
                f"?pageNum={page}&pageSize=15&bbsConfigFk=2"
                "&category&introPkId&title&content&username"
            )
            response = requests.get(list_url)
            data = response.json()
            notices = data["data"]["list"]

            for n in notices:
                rownum = n["rownum"]
                pkId = n["pkId"]
                title = n["title"]
                writer = n["userName"]
                date = n["regDate"]

                f.write(f"[{rownum}] {title} | {writer} | {date}\n")

                # 공지 상세 요청
                detail_url = f"{BASE_URL}/api/api/v1/mainKo/BbsData?pkId={pkId}"
                detail_resp = requests.get(detail_url)
                detail_data = detail_resp.json()["data"]

                html = detail_data.get("content", "")
                soup = BeautifulSoup(html, "html.parser")
                text = soup.get_text(separator="\n", strip=True)
                f.write(f"{text}\n")

                # PDF 탐지 및 처리
                pdf_urls = find_pdf_urls(html, detail_data)
                if pdf_urls:
                    print(f"  PDF {len(pdf_urls)}개 발견")

                    for idx, pdf_url in enumerate(pdf_urls, 1):
                        print(f"  [{idx}] {pdf_url}")
                        f.write(f"  PDF {idx}: {pdf_url}\n")

                        pdf_path = f"temp_{pkId}_{idx}.pdf"
                        try:
                            # 1. PDF 다운로드
                            download_pdf(pdf_url, pdf_path)

                            # 2. 텍스트 및 테이블 추출 후 txt에 기록
                            result = extract_pdf_text(pdf_path)
                            for page_info in result["pages"]:
                                f.write(f"  [Page {page_info['page']}]\n")
                                f.write(f"  {page_info['text']}\n")

                            for table_info in result["tables"]:
                                f.write(f"  [Table - Page {table_info['page']}]\n")
                                for row in table_info["data"]:
                                    f.write(f"  {row}\n")

                        except Exception as e:
                            f.write(f"  [PDF 오류: {e}]\n")

                        finally:
                            # 3. PDF 파일 제거 (성공/실패 무관)
                            if os.path.exists(pdf_path):
                                os.remove(pdf_path)
                                print(f"    삭제 완료: {pdf_path}")

                f.write("\n" + "=" * 60 + "\n")

    print(f"\n완료! {output_file} 저장됨")


if __name__ == "__main__":
    crawl_notices(page_count=1)

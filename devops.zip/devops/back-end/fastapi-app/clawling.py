import requests
import json
from bs4 import BeautifulSoup

file = open('crawl.txt', 'w', encoding='utf-8')

for i in range(1,2):
    url = "https://www.sogang.ac.kr/api/api/v1/mainKo/BbsData/boardList?pageNum="+str(i)+"&pageSize=15&bbsConfigFk=2&category&introPkId&title&content&username"
    response = requests.get(url)
    data = response.json()
    #json 파일에서 data안의 list에 정보가 담겨있음
    notices = data["data"]["list"]
    for n in notices:
        rownum = n["rownum"]
        pkId = n["pkId"]

        title = n["title"]
        writer = n["userName"]
        date = n["regDate"]
        #pkId를 대조해서 없을 때 DB에 추가
        file.write(f"{rownum} {title} {writer} {date}\n")

        #print(rownum, title, writer, date)

        #pkId를 통해 공지 내의 url도 크롤링
        
        notiurl = "https://www.sogang.ac.kr/api/api/v1/mainKo/BbsData?pkId="+str(pkId)
        notiresp = requests.get(notiurl)
        notidata = notiresp.json()
        html = notidata["data"]["content"]
        soup = BeautifulSoup(html, "html.parser")
        text = soup.get_text(separator="\n", strip=True)
        file.write(f"{text}\n")
        
file.close()
